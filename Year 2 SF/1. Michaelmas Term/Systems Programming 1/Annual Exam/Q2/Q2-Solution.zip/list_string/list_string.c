//   list_string.c
//   David Gregg
//   January 2021

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "list_string.h"

// create a new list string with the same value as a normal
// NULL-terminated C string
struct list_string *new_list_string(char *text)
{
    // creating a new list string
    struct list_string *result = malloc(sizeof(struct list_string));

    // initialize the head to be null
    result->head = NULL;

    // looping through the function parameter 'char *text'
    for (int i = 0; text[i] != '\0'; i++)
    {
        // creating a new node
        struct ls_node *temp_node = malloc(sizeof(struct ls_node));
        // assigning the char to c in ls_node
        temp_node->c = text[i];
        // pointing next branch to head
        temp_node->next = result->head;
        // changing the new node to be head
        result->head = temp_node;
    }
    // return the list string with text stored in its nodes as a linked list
    return result;
}

// find the length of the list string
int list_string_length(struct list_string *this)
{
    // assuming the length to be zero initially
    int length = 0;
    // Looping through the list_String through nodes till we reach the end
    for (struct ls_node *node = this->head; node != NULL; node = node->next)
    {
        length++;
        // Increasing the value of length for every char or node we pass through
    }
    // returning the length we got from the loop above
    return length;
}

// compare two strings;
// return -1 is s1 is lexicographically less that s2;
// return 0 if the strings are equal;
// return 1 if s1 is lexicographically larger than s2.
// E.g. "aB" is less than "ab" because 'B' has a smaller ASCII code than 'b'.
// Also "abc" is less that "abcd".
int list_string_compare(struct list_string *s1, struct list_string *s2)
{
    struct ls_node *node_s1 = s1->head;
    struct ls_node *node_s2 = s2->head;

    // Traversing both lists
    // break when we reach the end of a list string
    // or current characters in ls_node->c don't match
    while ((node_s1 != NULL && node_s2 != NULL) && (node_s1->c == node_s2->c))
    {
        node_s1 = node_s1->next;
        node_s2 = node_s2->next;
    }
    // comparing mismatch characters when both lists are not empty
    if (node_s1 != NULL && node_s2 != NULL)
    {
        // return 1 if s1 is lexicographically larger than s2.
        if (node_s1->c > node_s2->c)
        {
            return 1;
        }
        // return -1 if s1 is lexicographically lesser than s2.
        else
        {
            return -1;
        }
    }

    // If we still have'nt traversed both the lists completely
    // return 1 if we have'nt traveresed s1 and traversed s2 which implies
    // s1 is lexicographically larger than s2
    if (node_s1 != NULL && node_s2 == NULL)
    {
        return 1;
    }

    // return -1 if we have'nt traveresed s2 and traversed s1 which implies
    // if s1 is lexicographically lesser than s2.
    if (node_s2 != NULL && node_s1 == NULL)
    {
        return -1;
    }

    // If all the conditions are false, both the liststrings have reached their end
    // Which implies that the strings are lexicographically equal
    return 0;
}

// return 1 if str is a substring of text; 0 otherwise
int list_string_substring(struct list_string *text, struct list_string *str)
{
    //get lengths of text and str
    int length_str = list_string_length(str);
    int length_txt = list_string_length(text);

    //make a variable substr_found which will be used as a boolean to indicate a substring found
    int substr_found = 0;

    // looking for a substring if str is less than or equal to text
    if (length_str <= length_txt)
    {
        // set node_txt and node_str to the start of each string
        struct ls_node *node_txt = text->head;
        struct ls_node *node_str = str->head;

        //loop through the text until the end or until a substring is found
        while ((!substr_found) && (node_txt != NULL))
        {
            // if the present character in the text equals the first character of the search string
            if (node_txt->c == node_str->c)
            {
                // set substr_found to 1, this will only be set back to 0 if there is no substring in text
                substr_found = 1;

                // looping through the search string
                // break out of the for loop if we reach the end of the text before finishing the comparision and the boolean will be 0
                for (int i = 0; (i < length_str) && (node_txt != NULL); i++)
                {
                    // if the char in the text node matches with the char string node
                    // we traverse through the list string (linkedlist) by setting the nodes to their next pointers
                    if (node_txt->c == node_str->c)
                    {
                        node_str = node_str->next;
                        node_txt = node_txt->next;
                    }

                    // else implies there is not substring so set the boolean substr_found to 0,
                    // and reset node_str to the head of the str and break from the loop
                    else
                    {
                        substr_found = 0;
                        node_str = str->head;
                        break;
                    }
                }
            }
            // if the chars are different then we move to the next node in text by setting the next pointer as our present node
            else
            {
                node_txt = node_txt->next;
            }
        }
        //return substr_found, 1 if str is a substring of text, 0 in all other cases
        return substr_found;
    }
    // if str is longer then text it clearly cant be a sub string so instantly return 0
    else
    {
        return 0;
    }
}
