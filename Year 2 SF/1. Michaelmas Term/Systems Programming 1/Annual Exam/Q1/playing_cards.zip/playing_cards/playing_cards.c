//   playing_cards.c
//   David Gregg
//   December 2020

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "playing_cards.h"



// pack the playing card structures into bytes of memory
unsigned char * pack_playing_cards(struct playing_card * cards,
				   int number_of_cards) {

}




// unpack bytes of memory containing card data into playing card structures
struct playing_card * unpack_playing_cards(unsigned char * packed_cards,
					   int number_of_cards) {

}


